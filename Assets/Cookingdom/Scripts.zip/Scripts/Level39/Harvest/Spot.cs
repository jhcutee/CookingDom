using System;
using UnityEngine;

public class Spot : MonoBehaviour
{
    public bool IsHarvested { get; private set; }
    [Header("Elements")]
    [SerializeField] private Beetroot beetroot;

    [Header("Settings")]
    [SerializeField] private string harvestedTrigger = "Harvested";

    public event Action<Spot> HarvestArrived;
    private void Awake()
    {
        beetroot = GetComponentInChildren<Beetroot>();
    }
    public void Harvest()
    {
        if (IsHarvested) return;
        IsHarvested = true;
        beetroot.Animator?.SetTrigger(harvestedTrigger);
    }

    public void AnimEvent_HarvestArrived() => HarvestArrived?.Invoke(this);
}
