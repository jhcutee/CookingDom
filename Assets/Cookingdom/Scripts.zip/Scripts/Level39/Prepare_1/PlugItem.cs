using UnityEngine;

public class PlugItem : ItemBase
{

}
